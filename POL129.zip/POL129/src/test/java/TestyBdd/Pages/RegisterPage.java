package TestyBdd.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterPage extends BasePage{

    @FindBy(how = How.CSS, using = "#username")
    WebElement loginInput;


    @FindBy(how = How.XPATH, using = "//input[@name=\"login\"]")
    WebElement loginButton;

    @FindBy(how = How.CSS, using = ".woocommerce-error")
    WebElement errorMessage;






    public void fillLoginName(String name){
        loginInput.clear();
        loginInput.sendKeys(name);

    }

    public void clickLoginButton(){
        loginButton.click();
    }

    public String getErrorMessage(){
        return errorMessage.getText();
    }

}
