package TestyBdd.StepDefinitions;

import TestyBdd.Pages.RegisterPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

public class RegisterPageSteps {

    RegisterPage registerPage = new RegisterPage();



    @When("I fill login email input with {string}")
    public void iFillLoginEmailInputWith(String email) {
        registerPage.fillLoginName(email);
    }

    @When("I click Login button")
    public void iClickLoginButton() {
        registerPage.clickLoginButton();
    }

    @Then("I get notification {string} after login")
    public void iGetNotificationAfterLogin(String notifi) {
        Assertions.assertEquals(notifi,registerPage.getErrorMessage());
    }
}
