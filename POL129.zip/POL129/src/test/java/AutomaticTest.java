import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AutomaticTest {


    WebDriver driver;

    WebDriverWait wait;
    @BeforeEach


    public void driverSetup(){
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 5);

    }

    @AfterEach
    public void driverClose(){
        driver.quit();
    }
    @Test
    public void  FirstTest() {
        driver.get("https://sdacademy.pl/");
        String tytul = driver.getTitle();
        String url = driver.getCurrentUrl();
        System.out.println(tytul);
        System.out.println(url);
        driver.navigate().to("https://www.amazon.pl/");
        driver.navigate().back();
        driver.navigate().refresh();

    }

    @Test
    public void SecondTest(){
        driver.get("https://skleptest.pl/");
    WebElement accountButton = driver.findElement(By.linkText("Account"));
    WebElement mostWantedButton = driver.findElement(By.id("menu-item-128"));
    WebElement mail = driver.findElement(By.className("top-email"));
            }
            @Test
            public void ThirdTest(){
                driver.get("https://skleptest.pl/");
                WebElement searchInput = driver.findElement(By.cssSelector("#search-field-top-bar"));
                WebElement searchButton = driver.findElement(By.xpath("//button[@class=\"search-top-bar-submit\"]"));
                searchInput.clear();
                searchInput.sendKeys("dress");
                searchButton.click();
                WebElement mostWantedButton = driver.findElement(By.id("menu-item-128"));
                String text = mostWantedButton.getText();
                System.out.println(text);



                //System.out.println(searchButton.getTagName());
                //System.out.println(searchButton.getText());



            }

            @Test
            public void ForthTest(){
                driver.get("https://skleptest.pl/");
                WebElement accountButton = driver.findElement(By.xpath("//*[@id=\"page\"]/header[1]/div/div/div/ul/li[3]/a"));
                accountButton.click();
                WebElement  usernameField = driver.findElement(By.xpath("//*[@id=\"username\"]"));
                usernameField.clear();
                usernameField.sendKeys("XYZ");
                WebElement login = driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[1]/form/p[3]/input[3]"));
                login.click();
                WebElement info = driver.findElement(By.cssSelector(".woocommerce-error"));
                Assertions.assertEquals(info.getText(),"Error: The password field is empty.");


            }
            @Test
        public void FifthTest(){
                driver.get("https://skleptest.pl/");
                WebElement accountButton = driver.findElement(By.xpath("//*[@id=\"page\"]/header[1]/div/div/div/ul/li[3]/a"));
                accountButton.click();
                WebElement passwordField = driver.findElement(By.xpath("//*[@id=\"password\"]"));
                passwordField.clear();
                passwordField.sendKeys("zyx");
                WebElement login = driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[1]/form/p[3]/input[3]"));
                login.click();
                WebElement info = driver.findElement(By.cssSelector(".woocommerce-error"));
                Assertions.assertEquals(info.getText(),"Error: Username is required.");
            }


            @Test

        public void SixthTest(){
                driver.get("https://skleptest.pl/");
                WebElement searchInput = driver.findElement(By.cssSelector("#search-field-top-bar"));
                WebElement searchButton = driver.findElement(By.xpath("//button[@class=\"search-top-bar-submit\"]"));
                searchInput.clear();
                searchInput.sendKeys("dress");
                searchButton.click();
                WebElement head = driver.findElement(By.xpath("//*[@id=\"main\"]/header/h1"));
                Assertions.assertEquals(head.getText(),"SEARCH RESULTS FOR: DRESS");
            }

            @Test
        public void SeventhTest(){
        driver.get("https://skleptest.pl/product/little-black-top/");
                WebElement numberOfProductsInput = driver.findElement(By.xpath("//input[@name=\"quantity\"]"));
                numberOfProductsInput.clear();
                numberOfProductsInput.click();
                numberOfProductsInput.clear();
                numberOfProductsInput.sendKeys("1");
                WebElement addToCartButton = driver.findElement(By.xpath("//*[@id=\"product-17\"]/div[2]/form/button"));
                addToCartButton.click();
                WebElement goToCartButton = driver.findElement(By.cssSelector(".top-cart"));
                goToCartButton.click();
                WebElement numberOfClothes = driver.findElement(By.xpath("//input[@step=\"1\"]"));
                numberOfClothes.click();
                numberOfClothes.clear();
                numberOfClothes.sendKeys("2");
                WebElement updateCartButton = driver.findElement(By.xpath("//input[@name=\"update_cart\"]"));
                updateCartButton.click();
                WebElement proceedToCheckoutButton = driver.findElement(By.cssSelector(".wc-proceed-to-checkout"));
                      wait.until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton));
                Assertions.assertTrue(proceedToCheckoutButton.isEnabled());



            }

}


